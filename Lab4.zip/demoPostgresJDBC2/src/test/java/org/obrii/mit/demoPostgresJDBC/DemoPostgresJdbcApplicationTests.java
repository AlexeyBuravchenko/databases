package org.obrii.mit.demoPostgresJDBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoPostgresJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
